model-toolcall-adapter-rs v0.2.0 Linux ARM64

Run:
  chmod +x ./model-toolcall-adapter-rs
  ./model-toolcall-adapter-rs

Open:
  http://127.0.0.1:8787/ui
